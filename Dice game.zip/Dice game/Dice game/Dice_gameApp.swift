//
//  Dice_gameApp.swift
//  Dice game
//
//  Created by Дмитрий on 01.01.2024.
//

import SwiftUI

@main
struct Dice_gameApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
